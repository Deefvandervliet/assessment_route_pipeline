import datetime

import pytest
from pyspark import RDD
from pyspark.sql import DataFrame
from pyspark.sql.functions import col

from tests.conftest import dataframes_are_same

from typing import List


def test_source_get_dataframe(
        fruits_df,
        fruits_source,
):
    """
    Unit test for Source.get_dataframe()
    :param fruits_df:
    :param fruits_source:
    :return:
    """
    assert dataframes_are_same(
        fruits_source.get_dataframe(),
        fruits_df
    )


def test_source_get_dataframe_on_partitioned_data(
        fruits_df,
        fruits_source_partitioned,
):
    """
    Unit test for Source.get_dataframe() on partitioned data
    :param fruits_df:
    :param fruits_source_partitioned:
    :return:
    """
    assert dataframes_are_same(
        fruits_source_partitioned.get_dataframe(),
        fruits_df,
    )


def test_source_get_partition_dirs(
        fruits_df,
        fruits_source_partitioned,
):
    """
    assert that the method Source.get_partition_dirs() returns a list
    with the correct partition directories in them
    """
    # get partition column from dataframe
    partition_rows = fruits_df.select(col('import_date')).collect()
    dates = [column.import_date for column in partition_rows]
    partition_strings = [value.strftime('import_date=%Y-%m-%d/') for value in dates]
    print(f'partition_strings:{partition_strings}')

    # get partitions using Source.get_partition_dirs()
    source_partitions = fruits_source_partitioned.get_partition_dirs()
    print(f'source_partitions={source_partitions}')

    # ignore order and duplicates by converting to Sets
    s_partition_strings = set(partition_strings)
    s_source_partitions = set(source_partitions)

    print(f's_partition_strings:{s_partition_strings}')
    print(f's_source_partitions={s_source_partitions}')

    assert s_partition_strings == s_source_partitions


def test_source_get_partition_dirs_undefined_partition_column(
        fruits_df,
        fruits_source_partitioned,
):
    """
    Test Behaviour when retrieving partition information for a source with an
    undefined partition_column.
    :fixture fruits_df:
    :fixture fruits_source_partitioned:
    :return:
    """
    # set partition_column to None
    fruits_source_partitioned.partition_column = None

    with pytest.raises(ValueError):
        fruits_source_partitioned.get_partition_dirs()
    with pytest.raises(ValueError):
        fruits_source_partitioned.get_last_partition()
    with pytest.raises(ValueError):
        fruits_source_partitioned.get_dataframe_from_last_partition()


def test_source_get_partition_dirs_wrong_partition_column(
        fruits_df,
        fruits_source_partitioned,
):
    """
    Test Behaviour when retrieving partition information for a source with the
    a mismatch between source.partition_column and partitions on the filesystem
    :fixture fruits_df:
    :fixture fruits_source_partitioned:
    :return:
    """
    # set partition_column to None
    fruits_source_partitioned.partition_column = 'nosuch_column'

    assert fruits_source_partitioned.get_partition_dirs() == []
    assert fruits_source_partitioned.get_last_partition() is None
    with pytest.raises(ValueError):
        fruits_source_partitioned.get_dataframe_from_last_partition()


def test_delta_source_get_partition_dirs(
        fruits_df,
        fruits_delta_source_partitioned,
):
    """
    assert that the method Source.get_partition_dirs() returns a list
    with the correct partition directories in them for a delta format source
    """
    # get partition column from dataframe
    partition_column: str ='import_date'
    import_dates_rdd: RDD = fruits_df.select(partition_column).rdd.flatMap(lambda x: x)
    partition_strings: List[str] = import_dates_rdd.map(lambda x: x.strftime(f'{partition_column}=%Y-%m-%d/')).collect()

    print(f'partition_strings:{partition_strings}')

    # get partitions using Source.get_partition_dirs()
    source_partitions = fruits_delta_source_partitioned.get_partition_dirs()
    print(f'source_partitions={source_partitions}')

    # ignore order and duplicates by converting to Sets
    s_partition_strings = set(partition_strings)
    s_source_partitions = set(source_partitions)

    print(f's_partition_strings:{s_partition_strings}')
    print(f's_source_partitions={s_source_partitions}')

    assert s_partition_strings == s_source_partitions


def test_source_get_last_partition_import_date(
    fruits_df,
    fruits_source_partitioned,
    spark_session,
):
    """
    Unit test for get_last_partition()
    Assert that function returns the last partition directory
    :param fruits_df:
    :param fruits_source_partitioned:
    :param spark_session:
    :return:
    """
    last_partition = fruits_source_partitioned.get_last_partition()
    print(f'last_partition={last_partition}')

    assert last_partition == 'import_date=2022-06-07/'


def test_source_get_last_partition_import_date_s(
    fruits_df,
    fruits_source_partitioned_on_string,
    spark_session,
):
    """
    Unit test for get_last_partition()
    Assert that function returns the last partition directory
    :param fruits_df:
    :param fruits_source_partitioned:
    :param spark_session:
    :return:
    """
    last_partition = fruits_source_partitioned_on_string.get_last_partition()
    print(f'last_partition={last_partition}')

    assert last_partition == 'import_date_s=20220607000000/'


def test_source_get_dataframe_from_last_partition(
  fruits_df,
  fruits_source_partitioned,
):
    """
    Unit test for get_dataframe_from_last_partition() on parquet format
    Note: when returning the dataframe of a partition on parquet, the partition column
    should not be in the output
    :param fruits_df:
    :param fruits_delta_source_partitioned:
    :return:
    """
    df: DataFrame = fruits_df
    last_import_date: datetime.date = df.sort(df.import_date.desc()).select(df.import_date).collect()[0].import_date
    print(f'last import_date: {last_import_date}')

    df = df.filter(df.import_date == last_import_date)
    df = df.drop(df.import_date)

    assert dataframes_are_same(
        fruits_source_partitioned.get_dataframe_from_last_partition(),
        df,
    )


def test_delta_source_get_dataframe_from_last_partition(
  fruits_df,
  fruits_delta_source_partitioned,
):
    """
    Unit test for get_dataframe_from_last_partition() on delta format
    Note: when using delta the partition column is contained in the output
    :param fruits_df:
    :param fruits_delta_source_partitioned:
    :return:
    """
    df: DataFrame = fruits_df
    last_import_date: datetime.date = df.sort(df.import_date.desc()).select(df.import_date).collect()[0].import_date
    print(f'last import_date: {last_import_date}')

    df = df.filter(df.import_date == last_import_date)

    assert dataframes_are_same(
        fruits_delta_source_partitioned.get_dataframe_from_last_partition(),
        df,
    )