import pytest

from jobs.utils.models import DatabricksSecret
from jobs.utils.models import Source


def test_unknown_source_throws_exception(fake_etl_config):
    with pytest.raises(IndexError):
        fake_etl_config.get_source_by_name("no such source")


def test_get_source_by_name_returns_correct_source(fake_etl_config, source_a):
    source: Source = fake_etl_config.get_source_by_name(source_name=source_a.name)
    assert source == source_a


def test_get_data_dir(
        fake_etl_config,
        monkeypatch,
):
    source: Source = fake_etl_config.sources[0]

    # patch source_is_mounted() to always return False
    monkeypatch.setattr('jobs.utils.models.source_is_mounted', lambda *args, **kwargs: True)
    assert source.get_data_dir() == f'{source.mount_point}/{source.version}/data'

    # patch source_is_mounted() to always return False
    monkeypatch.setattr('jobs.utils.models.source_is_mounted', lambda *args, **kwargs: False)
    with pytest.raises(Exception):
        source.get_data_dir()


def test_get_data_dir_without_version(
        fake_etl_config,
        source_is_mounted,
):
    source: Source = fake_etl_config.sources[0]
    source.version = None

    assert source.get_data_dir() == f'{source.mount_point}/data'


def test_model_databrickssecrets_get(
        monkeypatch,
        fake_spark_session,
        fake_dbutils,
):
    secret = DatabricksSecret(
        key="answer_to_life_the_universe_and_everything",
        secret_scope="fake_scope_1"
    )

    # assert correct secret value is returned from model.DatabricksSecret instance
    assert secret.get() == 42

    # assert error is thrown when querying non existing scope
    secret.secret_scope = "no_such_scope"
    with pytest.raises(Exception):
        assert secret.get() is None

    # assert error is thrown when querying non existing secret
    secret.key = "no_such_key"
    with pytest.raises(Exception):
        assert secret.get() is None

    # test retrieval of secret from model.Source
    source_a = Source()
    source_a.client_id = "12345678"
    source_a.client_secret = "abcdefg"

    # test Source.get_client_id() when Source.client_id is a string
    assert source_a.get_client_id() == "12345678"
    assert source_a.get_client_secret() == "abcdefg"

    # test Source.get_client_id() when Source.client_id is a DatabricksSecret
    databricks_secret = DatabricksSecret(
        key="answer_to_life_the_universe_and_everything",
        secret_scope="fake_scope_1"
    )
    source_a.client_secret = databricks_secret
    assert source_a.get_client_secret() == 42


# mounting
def test_mount_s3_bucket(
        fake_dbutils,
        fake_s3_source,
):
    assert fake_s3_source.mount() is True


def test_unmount_s3_bucket(
        fake_dbutils,
        fake_s3_source,
):
    fake_s3_source.mount()
    assert fake_s3_source.unmount() is True
