import json
import common.spark

from typing import List
from typing import Optional
from typing import Union

from pydantic import BaseModel
from enum import Enum

from common.spark import get_secret
from common.spark import mount_point_in_use
from common.spark import mount_uri
from common.spark import source_is_mounted
from common.spark import unmount

from pyspark.sql import SparkSession
from pyspark.sql import DataFrame


class SparkFormatEnum(str, Enum):
    """
    Enum with valid Spark Formats
    """
    text = "text"
    parquet = "parquet"
    delta = "delta"
    csv = "csv"
    json = "json"
    orc = "orc"


class CurrencyEnum(str, Enum):
    """
    Currency Enum
    """
    EUR = "EUR"
    USD = "USD"
    JPY = "JPY"
    GBP = "GBP"


# FIXME: what about exceptions when secret is not there?
class DatabricksSecret(BaseModel):
    """
    Class for abstracting secrets in Databricks Secrets Scope
    """
    key: str = ""
    secret_scope: str = ""

    def get(self):
        return get_secret(secret_scope=self.secret_scope, key=self.key)


class Source(BaseModel):
    """
    Class for Abstracting handling of
    data on remote storage (ADLSGen2, S3) within Databricks
    """
    name: str = ''
    uri: str = ''
    version: Union[str, None] = None
    mount_point: str = ''
    format: SparkFormatEnum = SparkFormatEnum.parquet
    description: str = ''
    collibra_url: str = ''
    partition_column: Union[str, None] = None
    client_id: Union[str, DatabricksSecret, None]
    client_secret: Union[str, DatabricksSecret, None]
    tenant_id: Union[str, None] = None

    def get_data_dir(self) -> Optional[str]:
        """
        Returns the complete path to the data_dir, according to below schema:
        data_dir = <mount_point>/<version>/data/
        if the Source object is mounted, otherwise returns None
        The data_dir is the directory where the data will be written and
        can be directly passed to df.write.parquet(path=data_dir)
        """
        if self.version is not None:
            data_dir = f'{self.mount_point}/{self.version}/data'
        else:
            data_dir = f'{self.mount_point}/data'

        if self.is_mounted() is True:
            return data_dir
        else:
            raise Exception('source is not mounted, mount first!')

    def mount(self) -> bool:
        """
        Mounts source on mount_point
        returns True is has been or was mounted on mount_point
        """
        if self.is_mounted() is True:
            print(f'{self.uri} is already mounted on {self.mount_point}')
            return True
        else:
            if mount_point_in_use(self.mount_point) is True:
                print(f'mount_point: {self.mount_point} is in use by other source')
                return False
            else:
                return mount_uri(
                    source_uri=self.uri,
                    mount_point=self.mount_point,
                    client_id=self.get_client_id(),
                    client_secret=self.get_client_secret(),
                    tenant_id=self.tenant_id,
                )

    def is_mounted(self):
        """
        Calls helper function which indicates if source is mounted
        within Databricks
        :return: bool
        """
        return source_is_mounted(source=self.uri, mount_point=self.mount_point)

    def unmount(self):
        """
        Unmounts mounted storage in Databricks
        :return:
        """
        return unmount(mount_point=self.mount_point)

    def get_client_id(self) -> Optional[str]:
        """
        Getter function for retrieving client_id
        makes is possible the client_id to be stored as a string
        or within a Databricks secret.
        :return: str
        """
        if hasattr(self, 'client_id'):
            value = self.client_id
            if type(value) == str:
                return value
            elif type(value) == DatabricksSecret:
                return value.get()
            else:
                raise ValueError('client_id')
        return None

    def get_client_secret(self) -> Optional[str]:
        """
        Getter function for retrieving client_secret
        makes is possible for the client_secret to be stored as a string
        or within a Databricks secret.
        with a get method.
        :return: str
        """
        if hasattr(self, 'client_secret'):
            value = self.client_secret
            if type(value) == str:
                return value
            elif type(value) == DatabricksSecret:
                return value.get()
            else:
                raise ValueError('client_secret')
        return None

    def get_dataframe(self, rel_path: str = None) -> DataFrame:
        """
        Returns a Dataframe of the source data located at self.get_data_dir()
        :param rel_path: optional relative path to data_dir
        :return: pyspark.sql.Dataframe
        """
        data_dir: str = self.get_data_dir()

        if rel_path is None:
            path: str = f'{data_dir}'
        else:
            path: str = f'{data_dir}/{rel_path}'

        spark = self.__spark__()
        return spark.read.format(self.format).load(path=path)

    def get_dataframe_from_last_partition(self) -> Optional[DataFrame]:
        """
        Returns a Dataframe of the data within the last partition
        :return:
        """
        last_partition = self.get_last_partition()
        if last_partition is None:
            raise ValueError('invalid last partition, check your source and/or data')
        else:
            return self.get_dataframe(rel_path=last_partition)

    def get_partition_dirs(self) -> List[str]:
        """
        Returns a list of partition dirs in the data_dir. Based on the
        partition_column. If partition_column is not defined or no partition
        directories are found, it will return an empty list.
        an empty list.
        :return: List[str]
        """
        path = self.get_data_dir()
        if self.partition_column is None:
            raise ValueError('partition_column is None')
        else:
            return [file.name for file in self.__dbutils__().fs.ls(path) if f"{self.partition_column}=" in file.name]

    def get_last_partition(self) -> Optional[str]:
        """
        Returns the name (str) of the last partition directory
        in the data_dir. None if no partition directories are found.
        :return: Optional[str]
        """
        partition_dirs = self.get_partition_dirs()
        if len(partition_dirs) == 0:
            return None
        else:
            partition_dirs.sort()
            return partition_dirs[-1]

    @staticmethod
    def __spark__() -> SparkSession:
        return SparkSession.getActiveSession()

    @staticmethod
    def __dbutils__(spark: SparkSession = None):
        return common.spark.get_dbutils(spark_session=spark)


class ETLConfig(BaseModel):
    """
    A Pydantic ETL Configuration Class
    Bundling config, source(s) and destination
    """
    currencies: List[CurrencyEnum] = ["EUR"]
    minimum_amount: int = 50000
    sources: List[Source] = []
    destination: Source = Source()

    def get_source_by_name(self, source_name: str) -> Source:
        """
        returns a source indicated by name
        """
        try:
            _sources = self.sources
            _source = [source for source in self.sources if source.name == source_name][0]
            return _source
        except IndexError:
            print(f"source with name: {source_name} not found in config")
            raise

    @staticmethod
    def load_from_file(file_name: str):
        """
        Method for Instantiating the ETLConfig class from
        a json config file.
        :param file_name:
        :return: ETLConfig()
        """

        with open(file_name) as file:
            data = json.load(file)
            return ETLConfig(**data)
