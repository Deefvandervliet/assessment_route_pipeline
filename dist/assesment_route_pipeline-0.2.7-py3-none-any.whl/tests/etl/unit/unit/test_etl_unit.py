from tests.conftest import dataframes_are_same
from jobs.utils.etl import ETLVermogensOpbouw


# test utility function
def test_dataframes_are_same_function(spark_session):
    df1 = spark_session.range(1, 10)
    df2 = spark_session.range(1, 10)
    assert dataframes_are_same(df1, df2) is True


def test_active_customers(
        spark_session,
        spark_logger,
        etl_config,
        fake_customers,
        fake_active_customers,
        monkeypatch
):
    """
    Unit test for get_active_customers()
    :param spark_session:
    :param spark_logger:
    :param etl_config:
    :param fake_customers:
    :param fake_active_customers:
    :param monkeypatch:
    :return:
    """
    etl = ETLVermogensOpbouw(spark_session=spark_session, config=etl_config, logger=spark_logger)

    def mocked_get_customers():
        return fake_customers

    monkeypatch.setattr(etl, 'get_customers', mocked_get_customers)

    assert dataframes_are_same(etl.get_active_customers(), fake_active_customers)


def test_transaction_filtering(
        spark_session,
        spark_logger,
        etl_config,
        fake_transactions_filtered,
):
    """
    Unit test for get_filtered_transactions()
    :param spark_session:
    :param spark_logger:
    :param etl_config:
    :param fake_transactions_filtered:
    :return:
    """
    etl = ETLVermogensOpbouw(spark_session=spark_session, config=etl_config, logger=spark_logger)

    assert dataframes_are_same(etl.get_filtered_transactions(), fake_transactions_filtered)


def test_combine(
        spark_session,
        spark_logger,
        etl_config,
        fake_active_customers,
        fake_transactions_filtered,
        fake_combine_result,
        monkeypatch,
):
    """
    Unit test for combine() method
    :param spark_session:
    :param spark_logger:
    :param etl_config:
    :param fake_active_customers:
    :param fake_transactions_filtered:
    :param fake_combine_result:
    :return:
    """
    etl = ETLVermogensOpbouw(
        spark_session=spark_session,
        config=etl_config,
        logger=spark_logger
    )

    combined_df = etl.combine(
        active_customers=fake_active_customers,
        filtered_transactions=fake_transactions_filtered
    )

    print('fake_combine_result:')
    fake_combine_result.show()

    print('combined_df:')
    combined_df.show()

    assert dataframes_are_same(combined_df, fake_combine_result)
