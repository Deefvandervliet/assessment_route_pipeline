import pytest

from common.spark import is_running_in_databricks
from common.spark import only_in_databricks
from common.spark import get_dbutils
from common.spark import get_secret
from common.spark import mount_point_in_use
from common.spark import mount_s3
from common.spark import mount_adls_gen2
from common.spark import unmount
from common.spark import source_is_mounted


def test_is_running_in_databricks(monkeypatch):
    def f(val: str):
        return val

    monkeypatch.delenv('DATABRICKS_RUNTIME_VERSION', raising=False)
    assert is_running_in_databricks() is False
    assert only_in_databricks(f)('hi-di-ho') is None

    monkeypatch.setenv('DATABRICKS_RUNTIME_VERSION', '0.1')
    assert is_running_in_databricks() is True
    assert only_in_databricks(f)('hi-di-ho') == 'hi-di-ho'


def test_get_dbutils(
        fake_spark_session,
        fake_dbutils
):
    assert get_dbutils() is not None
    assert type(get_dbutils()) == type(fake_dbutils(fake_spark_session))


def test_get_secret(
        fake_dbutils,
        fake_secrets,
):
    assert get_secret(secret_scope='fake_scope_1', key='answer_to_life_the_universe_and_everything') == 42


def test_s3_mounting(
        fake_s3_uri,
        fake_aws_identity,
        fake_aws_secret_scope,
        fake_dbutils,
):
    """
    test common.spark mounting functions
    """
    mount_point = '/mnt/amazing_data'

    assert mount_s3(
        source_uri=fake_s3_uri,
        mount_point=mount_point,
        access_key_id=fake_aws_identity.access_key_id,
        secret_access_key=fake_aws_identity.secret_access_key,
    ) is True

    assert source_is_mounted(source=fake_s3_uri, mount_point=mount_point) is True
    assert mount_point_in_use(mount_point=mount_point) is True


def test_abfss_mounting(
        fake_abfss_uri,
        fake_azure_identity,
        fake_dbutils,
):
    """
    test common.spark mounting functions
    """
    mount_point = '/mnt/amazing_data'

    assert mount_adls_gen2(
        source_uri=fake_abfss_uri,
        mount_point=mount_point,
        sp_app_id=fake_azure_identity.appId,
        sp_secret=fake_azure_identity.password,
        tenant_id=fake_azure_identity.tenantId
    ) is True

    assert source_is_mounted(source=fake_abfss_uri, mount_point=mount_point) is True
    assert mount_point_in_use(mount_point=mount_point) is True


def test_umounting(
        fake_abfss_uri,
        fake_azure_identity,
        fake_dbutils,
):
    """
    test common.spark mounting functions
    """
    mount_point = '/mnt/amazing_data'

    mount_adls_gen2(
        source_uri=fake_abfss_uri,
        mount_point=mount_point,
        sp_app_id=fake_azure_identity.appId,
        sp_secret=fake_azure_identity.password,
        tenant_id=fake_azure_identity.tenantId
    )

    # assert failure
    with pytest.raises(Exception):
        assert unmount('/no/such/mount/point')

    assert unmount(
        mount_point=mount_point
    ) is True

    assert source_is_mounted(source=fake_abfss_uri, mount_point=mount_point) is False
    assert mount_point_in_use(mount_point=mount_point) is False
