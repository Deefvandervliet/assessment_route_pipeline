from common.logging import Log4j
from common.spark import get_dbutils

from datetime import datetime

from jobs.utils.models import ETLConfig
from jobs.utils.models import CurrencyEnum
from jobs.utils.models import Source

from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.functions import lit

from typing import List

"""
etl.py
~~~~~~~~~~
This module contains the ETL functions for vermogensopbouw

Dataset owner: team Shebang
Code owner: team Shebang
Code creator(s): Dave and his Supremes
"""


class ETLVermogensOpbouw(object):
    """
    Returns an ETL class specific for the implementation of
    VermogensOpbouw.
    - etl = ETL(...)
    - etl.mount_all()
    - etl.run()
    """

    def __init__(self, spark_session: SparkSession, config: ETLConfig, logger: Log4j):
        self.spark = spark_session
        self.config: ETLConfig = config
        self.log = logger
        self.dbutils = get_dbutils(spark_session)

    def get_booking_information(self) -> DataFrame:
        """
        Returns last partition of cna_booking_information as DataFrame
        """
        self.log.info(f'{self}.get_booking_information()')
        source: Source = self.config.get_source_by_name(source_name="cna_booking_information")
        self.log.info(f'source:{source}')
        return source.get_dataframe_from_last_partition()

    def get_customers(self) -> DataFrame:
        """
        Returns cdf_ggm_rel_x_ar_hist as DataFrame
        """
        self.log.info(f'{self}.get_customers()')
        source: Source = self.config.get_source_by_name(source_name="cdf_ggm_rel_x_ar_hist")
        self.log.info(f'source:{source}')
        return source.get_dataframe()

    def get_filtered_transactions(self) -> DataFrame:
        """
        Returns all credit transactions larger then a minimum amount in cents
        """
        self.log.info(f'{self}.get_filtered_transactions()')
        currencies: List[CurrencyEnum] = self.config.currencies
        minimum_amount_in_cents: int = self.config.minimum_amount * 100  # convert to cents
        self.log.info(f'currencies:{currencies}')
        self.log.info(f'minimum_amount_in_cents:{minimum_amount_in_cents}')
        df: DataFrame = self.get_booking_information()

        # rename columns
        df = df.withColumnRenamed("acct_id", "iban")\
            .withColumnRenamed("acct_ccy", "currency")\
            .withColumnRenamed("bookg_amt_nmrc", "booking_amount")\
            .withColumnRenamed("bookg_amt", "booking_amount_formatted")\
            .withColumnRenamed("bookg_cdt_dbt_ind", "credit_debit_indicator")\
            .withColumnRenamed("bookg_dt", "booking_date")

        df = df.where(
            (col("booking_amount") > minimum_amount_in_cents) &
            (col("currency").isin(currencies)) &
            (col("credit_debit_indicator") == "CRDT")
        )

        return df

    def get_active_customers(self) -> DataFrame:
        """
        Return a DataFrame containing all distinct active customers with a valid
        iban and rel_id
        """
        self.log.info(f'{self}.get_active_customers()')
        df: DataFrame = self.get_customers()

        # First we comply to the business rules of the data consumer to get an "active" set
        # https://confluence.dev.rabobank.nl/pages/viewpage.action?spaceKey=DLD&title=CDF+3.+DERIVED+DATASETS
        # The active set will filter out records that are physicly deleted from siebel.
        # the active set still contains records which we need to filter out:
        # Filter out so-called inactive customers
        # Filter out records with null values for columns : REL_ID and IBAN
        # After the filtering, we select the relevant columns
        # output will be a unique /distinct list of siebelid and iban

        df: DataFrame = df.where(
            (col('EDL_VALID_TO_DTS') == '9999-12-31') &
            (col('AR_DEL_F') == 'N') &
            (col('INTERSECTION_DEL_F') == 'N') &
            (col('AR_ST_GGM_CODE') == 'Actief') &
            col('AR_AC_IBAN').isNotNull() &
            col('REL_ID').isNotNull()
        ) \
            .select('REL_ID', 'AR_AC_IBAN') \
            .distinct()

        # rename columns
        df = df.withColumnRenamed("REL_ID", "customerid") \
            .withColumnRenamed("AR_AC_IBAN", "iban")

        return df

    @staticmethod
    def combine(
            filtered_transactions: DataFrame,
            active_customers: DataFrame,
    ) -> DataFrame:
        """
        Returns a DataFrame combining filtered transactions with active customers
        """
        df: DataFrame = filtered_transactions.alias("tra") \
            .join(active_customers.alias("cst"), "iban") \
            .select("cst.customerid", "tra.booking_amount_formatted")

        return df

    def mount_all(self):
        """
        Mount all source(s) and destination
        :return: True if everything is mounted, False otherwise
        """
        self.log.info(f'{self}.mount_all():')
        mount_status: List[bool] = [source.mount() for source in self.config.sources]
        mount_status.append(self.config.destination.mount())
        self.log.info(f'mount_status: {mount_status}')
        return all(mount_status)

    def write_output(self, df: DataFrame):
        """
        Add timestamp column and write DataFrame to config.destination
        """
        self.log.info(f'{self}.write_output():')
        destination: Source = self.config.destination

        timestamp: str = datetime.utcnow().strftime('%Y%m%d%H%M%S')
        self.log.info(f'adding column load_time_utc_s: {timestamp}')
        df = df.withColumn('load_time_utc_s', lit(timestamp))

        self.log.info(f'destination: {destination}')
        self.log.info('writing dataframe..')
        df.write \
            .format(destination.format)\
            .mode("append")\
            .save(path=destination.get_data_dir(), partitionBy=destination.partition_column)

    def run(self):
        """
        Runs through the whole ETL flow:
        - retrieve/determine filtered transactions
        - retrieve/determine active customers
        - combine (join) both
        and store the result in config.destination
        """
        self.log.info(f'{self}.run():')

        self.log.info('self.combine() start')
        df: DataFrame = self.combine(
            filtered_transactions=self.get_filtered_transactions(),
            active_customers=self.get_active_customers()
        )
        self.log.info('self.combine() done')
        self.write_output(df)
